# Back at the habitat: the cuff again, and a fresh look at the air
tellraw @a {"text":""}
tellraw @a {"text":"You are at the habitat. Cuff:"}
function marscuff:cuff
