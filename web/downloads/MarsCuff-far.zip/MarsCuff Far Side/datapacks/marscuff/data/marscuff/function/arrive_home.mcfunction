scoreboard players set #home mc_at 1
function marscuff:habitat
