scoreboard players set #st1 mc_at 1
function marscuff:station1
