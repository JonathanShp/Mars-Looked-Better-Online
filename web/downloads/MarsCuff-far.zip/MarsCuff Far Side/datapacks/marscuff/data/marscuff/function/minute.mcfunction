# One EVA minute has passed
scoreboard players set #ticks mc_clock 0
scoreboard players remove #air mc_air 1
execute if score #air mc_air matches ..0 if score #spent mc_air matches 0 run function marscuff:out_of_air
