scoreboard players set #st2 mc_at 1
function marscuff:station2
