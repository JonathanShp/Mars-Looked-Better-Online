# The budget ran out. Nothing is taken away from you - this is the honest
# result of the plan, the same as a crew missing its walk-back margin.
scoreboard players set #spent mc_air 1
scoreboard players set #air mc_air 0
title @a title {"text":"OUT OF AIR"}
tellraw @a {"text":"Your air budget is gone. On a real EVA this is the walk you did not"}
tellraw @a {"text":"come back from. Plan a shorter route on the website and try again."}
