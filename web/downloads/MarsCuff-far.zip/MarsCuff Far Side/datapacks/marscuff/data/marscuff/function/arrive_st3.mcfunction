scoreboard players set #st3 mc_at 1
function marscuff:station3
