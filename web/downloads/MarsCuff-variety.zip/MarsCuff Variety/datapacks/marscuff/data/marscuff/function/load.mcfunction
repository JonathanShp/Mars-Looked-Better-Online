# Start the walk at the habitat
setworldspawn 4 15 -14

# Mission set-up. Re-run every time the world opens = a fresh EVA.
scoreboard objectives add mc_air dummy
scoreboard objectives add mc_clock dummy
scoreboard objectives add mc_at dummy
scoreboard players set #air mc_air 384
scoreboard players set #spent mc_air 0
scoreboard players set #ticks mc_clock 0
scoreboard players set #home mc_at 0
scoreboard players set #st1 mc_at 0
scoreboard players set #st2 mc_at 0
scoreboard players set #st3 mc_at 0
tellraw @a {"text":""}
tellraw @a {"text":"MARSCUFF: a 384 minute EVA. The air number above your hotbar is"}
tellraw @a {"text":"your whole budget - walking, working and the walk home."}
tellraw @a {"text":"Follow the glowing line. Stand at a pillar to get your tasks."}
tellraw @a {"text":"Press F3 for coordinates. Your stops:"}
tellraw @a {"text":"  Station 1: X -1361  Z -294  (1.4 km west of the last stop)"}
tellraw @a {"text":"  Station 2: X 687  Z 1146  (2.0 km south-east of the last stop)"}
tellraw @a {"text":"  Station 3: X -982  Z 1066  (1.7 km west of the last stop)"}
scoreboard players set #tp mc_at 0
