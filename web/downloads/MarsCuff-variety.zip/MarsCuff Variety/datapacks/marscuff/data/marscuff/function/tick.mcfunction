# Mars gravity (0.378 x Earth) for every player
execute as @a run attribute @s minecraft:gravity base set 0.0302
execute as @a run attribute @s minecraft:safe_fall_distance base set 7.9

# The mission clock. Runs every tick, as the server, for everyone online.
scoreboard players add #ticks mc_clock 1
execute if score #ticks mc_clock matches 200.. run function marscuff:minute
# Air left, above the hotbar, all the time.
title @a actionbar [{"text":"Air: "},{"score":{"name":"#air","objective":"mc_air"}},{"text":" min of 384"}]
# habitat
execute if score #home mc_at matches 0 positioned 4 15 -14 if entity @a[distance=..30] run function marscuff:arrive_home
execute if score #home mc_at matches 1 positioned 4 15 -14 unless entity @a[distance=..60] run scoreboard players set #home mc_at 0
# station1
execute if score #st1 mc_at matches 0 positioned -1361 24 -294 if entity @a[distance=..30] run function marscuff:arrive_st1
execute if score #st1 mc_at matches 1 positioned -1361 24 -294 unless entity @a[distance=..60] run scoreboard players set #st1 mc_at 0
# station2
execute if score #st2 mc_at matches 0 positioned 687 -6 1146 if entity @a[distance=..30] run function marscuff:arrive_st2
execute if score #st2 mc_at matches 1 positioned 687 -6 1146 unless entity @a[distance=..60] run scoreboard players set #st2 mc_at 0
# station3
execute if score #st3 mc_at matches 0 positioned -982 13 1066 if entity @a[distance=..30] run function marscuff:arrive_st3
execute if score #st3 mc_at matches 1 positioned -982 13 1066 unless entity @a[distance=..60] run scoreboard players set #st3 mc_at 0

# First tick of the session: put everyone at the habitat. level.dat still
# carries the old spawn point, and setworldspawn does not move a player who is
# already standing in the world, so we move them once, here.
execute if score #tp mc_at matches 0 if entity @a run teleport @a 4 16 -14
execute if score #tp mc_at matches 0 if entity @a run scoreboard players set #tp mc_at 1
