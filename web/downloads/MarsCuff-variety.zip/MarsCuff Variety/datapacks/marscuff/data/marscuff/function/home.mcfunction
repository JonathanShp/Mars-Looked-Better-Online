# /function marscuff:home - back to the habitat
teleport @s 4 15 -14
