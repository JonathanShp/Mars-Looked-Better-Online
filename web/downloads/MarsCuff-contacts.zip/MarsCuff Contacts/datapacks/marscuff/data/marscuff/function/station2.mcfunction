# Arrived at station 2
tellraw @a {"text":""}
tellraw @a {"text":"=== STATION 2 ==="}
tellraw @a {"text":"Rock unit here: Crater floor fractured rough"}
tellraw @a {"text":"Leave by 5:56 on the clock or you will not make it home."}
tellraw @a {"text":"- Station recon panorama (5 min) - Mastcam-Z, the stereo zoom cameras on the mast"}
tellraw @a {"text":"- Remote triage of three targets (4 min) - SuperCam, laser spectroscopy from a distance (out to roughly 7 m)"}
tellraw @a {"text":"- Read the contact (12 min) IF TIME - classic field geology, the way Apollo crews worked a traverse"}
