# The cuff, printed in chat
tellraw @a {"text":""}
tellraw @a {"text":"=== YOUR CUFF ==="}
tellraw @a {"text":"MARSCUFF"}
tellraw @a {"text":"Jezero EVA cuff"}
tellraw @a {"text":"7.52 km walk"}
tellraw @a {"text":"4:00 of 6:24 usable"}
tellraw @a {"text":"FITS"}
tellraw @a {"text":"No Point of No Return"}
tellraw @a {"text":"---"}
tellraw @a {"text":"HOW TO FOLLOW"}
tellraw @a {"text":"WHITE = habitat."}
tellraw @a {"text":"PURPLE = stations."}
tellraw @a {"text":"RED = no return."}
tellraw @a {"text":"Glowing = route."}
tellraw @a {"text":"(beams in game,"}
tellraw @a {"text":"pillars in the zip)"}
tellraw @a {"text":"---"}
tellraw @a {"text":"TIMELINE"}
tellraw @a {"text":"0:00 Leave habitat"}
tellraw @a {"text":"0:30 Arrive sta 1 (go by 5:55)"}
tellraw @a {"text":"1:00 Leave sta 1"}
tellraw @a {"text":"1:27 Arrive sta 2 (go by 5:56)"}
tellraw @a {"text":"1:57 Leave sta 2"}
tellraw @a {"text":"2:53 Arrive sta 3 (go by 5:47)"}
tellraw @a {"text":"3:23 Leave sta 3"}
tellraw @a {"text":"4:00 Back at habitat"}
tellraw @a {"text":"---"}
tellraw @a {"text":"AT THE HABITAT"}
tellraw @a {"text":"Weather and dust log, 3 min"}
tellraw @a {"text":"Do it before you leave and again when you get back."}
tellraw @a {"text":"WHERE"}
tellraw @a {"text":"At the habitat, once before you leave and again when you get back."}
tellraw @a {"text":"STEPS"}
tellraw @a {"text":"1. Note the time, the temperature, the wind direction and how hard it is blowing."}
tellraw @a {"text":"2. Look across the crater floor for dust devils and count them."}
tellraw @a {"text":"3. Photograph the sky to the north with the same exposure both times, so the haze can be compared."}
tellraw @a {"text":"4. If the view got hazier while you were out, say so. It changes how your pictures should be read."}
tellraw @a {"text":"---"}
tellraw @a {"text":"STATION 1"}
tellraw @a {"text":"Crater floor fractured 1"}
tellraw @a {"text":"Arrive 0:30"}
tellraw @a {"text":"Leave by 5:55"}
tellraw @a {"text":"WHY HERE"}
tellraw @a {"text":"- No rover has ever driven on this rock type. Texture and chemistry up close: nobody has ever had this rock in front of them"}
tellraw @a {"text":"- A mapped contact between two rock units runs through here. Which rock sits on top of which, and therefore which one is older"}
tellraw @a {"text":"---"}
tellraw @a {"text":"STATION 1 JOBS"}
tellraw @a {"text":"30 min must-do, 30 min booked, +12 if time"}
tellraw @a {"text":"1. Station recon panorama (5 min)"}
tellraw @a {"text":"2. Remote triage of three targets (4 min)"}
tellraw @a {"text":"3. Abrade a patch and look inside (9 min)"}
tellraw @a {"text":"4. Elemental map of the fresh patch (4 min)"}
tellraw @a {"text":"5. Take a sealed core (8 min)"}
tellraw @a {"text":"6. Read the contact (12 min) IF TIME"}
tellraw @a {"text":"---"}
tellraw @a {"text":"STA 1 JOB 1"}
tellraw @a {"text":"Station recon panorama"}
tellraw @a {"text":"5 min"}
tellraw @a {"text":"WHERE"}
tellraw @a {"text":"Stand still at the station pin, on the flattest ground within about 5 m."}
tellraw @a {"text":"STEPS"}
tellraw @a {"text":"1. Put the scale bar (or your own boot, 30 cm) in view and note which way is north."}
tellraw @a {"text":"2. Shoot a full circle of overlapping photos from one spot, about 20 degrees apart, held level."}
tellraw @a {"text":"3. Shoot the same circle again one pace to the right, so the pair is stereo and gives depth."}
tellraw @a {"text":"4. Say out loud and write down: station number, time on the EVA clock, what the ground is made of."}
tellraw @a {"text":"---"}
tellraw @a {"text":"STA 1 JOB 2"}
tellraw @a {"text":"Remote triage of three targets"}
tellraw @a {"text":"4 min"}
tellraw @a {"text":"WHERE"}
tellraw @a {"text":"Pick three rocks 2 to 7 m away that differ: one bedrock face, one loose rock, one dusty patch."}
tellraw @a {"text":"STEPS"}
tellraw @a {"text":"1. Number the three targets in the panorama and photograph each one zoomed in."}
tellraw @a {"text":"2. For each: note grain size, colour, layering, and whether it is in place or loose."}
tellraw @a {"text":"3. Rank them for the next protocol. In place beats loose; a fresh face beats a dusty one."}
tellraw @a {"text":"4. Write down the one you rejected and why. A rejection is data too."}
tellraw @a {"text":"---"}
tellraw @a {"text":"STA 1 JOB 3"}
tellraw @a {"text":"Abrade a patch and look inside"}
tellraw @a {"text":"9 min"}
tellraw @a {"text":"WHERE"}
tellraw @a {"text":"On bedrock still attached to the ground, on a face you can reach standing up."}
tellraw @a {"text":"STEPS"}
tellraw @a {"text":"1. Brush the dust off a patch about the size of your palm."}
tellraw @a {"text":"2. Grind a flat patch about 5 cm across and a few mm deep, the size Perseverance makes."}
tellraw @a {"text":"3. Photograph the patch close up, filling the frame, with the scale bar touching it."}
tellraw @a {"text":"4. Describe the fresh surface: grain size, cement between grains, veins, how it differs from the rind."}
tellraw @a {"text":"5. Shade the patch with your body and look for anything that glows. That is the organics check."}
tellraw @a {"text":"---"}
tellraw @a {"text":"STATION 2"}
tellraw @a {"text":"Crater floor fractured rough"}
tellraw @a {"text":"Arrive 1:27"}
tellraw @a {"text":"Leave by 5:56"}
tellraw @a {"text":"WHY HERE"}
tellraw @a {"text":"- A mapped contact between two rock units runs through here. Which rock sits on top of which, and therefore which one is older"}
tellraw @a {"text":"---"}
tellraw @a {"text":"STATION 2 JOBS"}
tellraw @a {"text":"9 min must-do, 30 min booked, +12 if time"}
tellraw @a {"text":"1. Station recon panorama (5 min)"}
tellraw @a {"text":"2. Remote triage of three targets (4 min)"}
tellraw @a {"text":"3. Read the contact (12 min) IF TIME"}
tellraw @a {"text":"---"}
tellraw @a {"text":"STA 2 JOB 1"}
tellraw @a {"text":"Station recon panorama"}
tellraw @a {"text":"5 min"}
tellraw @a {"text":"WHERE"}
tellraw @a {"text":"Stand still at the station pin, on the flattest ground within about 5 m."}
tellraw @a {"text":"STEPS"}
tellraw @a {"text":"1. Put the scale bar (or your own boot, 30 cm) in view and note which way is north."}
tellraw @a {"text":"2. Shoot a full circle of overlapping photos from one spot, about 20 degrees apart, held level."}
tellraw @a {"text":"3. Shoot the same circle again one pace to the right, so the pair is stereo and gives depth."}
tellraw @a {"text":"4. Say out loud and write down: station number, time on the EVA clock, what the ground is made of."}
tellraw @a {"text":"---"}
tellraw @a {"text":"STA 2 JOB 2"}
tellraw @a {"text":"Remote triage of three targets"}
tellraw @a {"text":"4 min"}
tellraw @a {"text":"WHERE"}
tellraw @a {"text":"Pick three rocks 2 to 7 m away that differ: one bedrock face, one loose rock, one dusty patch."}
tellraw @a {"text":"STEPS"}
tellraw @a {"text":"1. Number the three targets in the panorama and photograph each one zoomed in."}
tellraw @a {"text":"2. For each: note grain size, colour, layering, and whether it is in place or loose."}
tellraw @a {"text":"3. Rank them for the next protocol. In place beats loose; a fresh face beats a dusty one."}
tellraw @a {"text":"4. Write down the one you rejected and why. A rejection is data too."}
tellraw @a {"text":"---"}
tellraw @a {"text":"STATION 3"}
tellraw @a {"text":"Crater floor fractured 1"}
tellraw @a {"text":"Arrive 2:53"}
tellraw @a {"text":"Leave by 5:47"}
tellraw @a {"text":"WHY HERE"}
tellraw @a {"text":"- No rover has ever driven on this rock type. Texture and chemistry up close: nobody has ever had this rock in front of them"}
tellraw @a {"text":"- A mapped contact between two rock units runs through here. Which rock sits on top of which, and therefore which one is older"}
tellraw @a {"text":"---"}
tellraw @a {"text":"STATION 3 JOBS"}
tellraw @a {"text":"30 min must-do, 30 min booked, +12 if time"}
tellraw @a {"text":"1. Station recon panorama (5 min)"}
tellraw @a {"text":"2. Remote triage of three targets (4 min)"}
tellraw @a {"text":"3. Abrade a patch and look inside (9 min)"}
tellraw @a {"text":"4. Elemental map of the fresh patch (4 min)"}
tellraw @a {"text":"5. Take a sealed core (8 min)"}
tellraw @a {"text":"6. Read the contact (12 min) IF TIME"}
tellraw @a {"text":"---"}
tellraw @a {"text":"STA 3 JOB 1"}
tellraw @a {"text":"Station recon panorama"}
tellraw @a {"text":"5 min"}
tellraw @a {"text":"WHERE"}
tellraw @a {"text":"Stand still at the station pin, on the flattest ground within about 5 m."}
tellraw @a {"text":"STEPS"}
tellraw @a {"text":"1. Put the scale bar (or your own boot, 30 cm) in view and note which way is north."}
tellraw @a {"text":"2. Shoot a full circle of overlapping photos from one spot, about 20 degrees apart, held level."}
tellraw @a {"text":"3. Shoot the same circle again one pace to the right, so the pair is stereo and gives depth."}
tellraw @a {"text":"4. Say out loud and write down: station number, time on the EVA clock, what the ground is made of."}
tellraw @a {"text":"---"}
tellraw @a {"text":"STA 3 JOB 2"}
tellraw @a {"text":"Remote triage of three targets"}
tellraw @a {"text":"4 min"}
tellraw @a {"text":"WHERE"}
tellraw @a {"text":"Pick three rocks 2 to 7 m away that differ: one bedrock face, one loose rock, one dusty patch."}
tellraw @a {"text":"STEPS"}
tellraw @a {"text":"1. Number the three targets in the panorama and photograph each one zoomed in."}
tellraw @a {"text":"2. For each: note grain size, colour, layering, and whether it is in place or loose."}
tellraw @a {"text":"3. Rank them for the next protocol. In place beats loose; a fresh face beats a dusty one."}
tellraw @a {"text":"4. Write down the one you rejected and why. A rejection is data too."}
tellraw @a {"text":"---"}
tellraw @a {"text":"EMERGENCY"}
tellraw @a {"text":"Sta 1: 0:29 walk home"}
tellraw @a {"text":"Sta 2: 0:28 walk home"}
tellraw @a {"text":"Sta 3: 0:37 walk home"}
tellraw @a {"text":"Suit alarm: walk straight home."}
tellraw @a {"text":"8 jobs did not fit this book: those steps are on the printed cuff and the website."}
tellraw @a {"text":"---"}
tellraw @a {"text":"SOURCES"}
tellraw @a {"text":"Ground: USGS CTX DTM (MRO). Rocks: Stack et al. 2020. Tracks: NASA/JPL Mars 2020. Jobs: Mars 2020 instrument papers (Mastcam-Z, SuperCam, SHERLOC, PIXL, MEDA). Times: MODEL (Tobler x 0.6, team assumptions). 1 block = 1 m."}
tellraw @a {"text":"---"}
tellraw @a {"text":"Watch the air number above your hotbar. Walking home costs air too."}
