# At the habitat. Short on purpose: the full cuff is in HOW-TO-USE.txt.
tellraw @a {"text":""}
tellraw @a {"text":"HABITAT. Start and finish here."}
tellraw @a {"text":"Next: Station 1, 1.4 km west - follow the glowing line."}
tellraw @a {"text":"Your tasks print when you reach a purple pillar."}
