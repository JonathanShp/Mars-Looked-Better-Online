# Arrived at station 3
tellraw @a {"text":""}
tellraw @a {"text":"=== STATION 3 ==="}
tellraw @a {"text":"Rock unit here: Crater floor fractured 1"}
tellraw @a {"text":"Leave by 5:47 on the clock or you will not make it home."}
tellraw @a {"text":"- Station recon panorama (5 min) - Mastcam-Z, the stereo zoom cameras on the mast"}
tellraw @a {"text":"- Remote triage of three targets (4 min) - SuperCam, laser spectroscopy from a distance (out to roughly 7 m)"}
tellraw @a {"text":"- Abrade a patch and look inside (9 min) - the abrading bit with WATSON and SHERLOC (close-up camera, deep-UV Raman and fluorescence)"}
tellraw @a {"text":"- Elemental map of the fresh patch (4 min) - PIXL, micro X-ray fluorescence with a spot about a tenth of a millimetre wide"}
tellraw @a {"text":"- Take a sealed core (8 min) - the Mars 2020 coring bit and sample tubes"}
tellraw @a {"text":"- Read the contact (12 min) IF TIME - classic field geology, the way Apollo crews worked a traverse"}
